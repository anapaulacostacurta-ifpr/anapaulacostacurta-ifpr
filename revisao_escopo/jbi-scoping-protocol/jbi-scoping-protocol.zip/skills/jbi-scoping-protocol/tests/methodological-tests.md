# 18. CRITÉRIOS DE VALIDAÇÃO

## 18.1. Validação estrutural

Verificar a existência das seções metodológicas necessárias.

## 18.2. Validação conceitual

Verificar a coerência entre tema, PCC, pergunta e objetivos.

## 18.3. Validação operacional

Verificar se os procedimentos planejados são suficientemente descritos para reprodução.

## 18.4. Validação documental

Verificar fontes, versões, apêndices, referências e evidências de aprovação.

## 18.5. Validação prospectiva PRISMA-ScR

Verificar se o planejamento contempla os requisitos de relato aplicáveis à fase de protocolo.

## 18.6. Validação PRISMA-S

Verificar a documentação disponível das estratégias e procedimentos de busca.

## 18.7. Classificação das ocorrências

| Nível | Descrição |
|---|---|
| Crítico | Compromete a integridade ou coerência metodológica |
| Alto | Impede a consolidação de uma versão aprovada |
| Moderado | Requer esclarecimento ou complementação |
| Baixo | Melhoria documental recomendada |
| Informativo | Registro de observação |
# 25. CASO DE TESTE DE REFERÊNCIA

Utilizar como cenário inicial de homologação uma revisão de escopo sobre jogos com integração físico-digital no contexto de Redes de Computadores.

Documentos e informações disponíveis:

- Protocolo JBI v0.2, referenciado no documento de origem.
- Apêndice I — Estratégias preliminares de busca na Scopus v0.1.
- Estratégia principal S0-SCOPUS-P.
- Estratégia complementar S0-SCOPUS-C.
- Blocos conceituais B1, B2 e B3.
- Previsão de participação dos pesquisadores R1, R2 e R3.
- Previsão de outras sete fontes de informação.
- Buscas ainda não executadas, conforme o apêndice.

Comportamento esperado:

- Preservar as estratégias originais.
- Não presumir acesso ao conteúdo integral do protocolo JBI v0.2.
- Não inventar as outras sete fontes.
- Identificar a relação de inclusão lógica entre as estratégias.
- Gerar o registro PRISMA-S preliminar.
- Registrar as pendências de calibração e execução.
- Preservar o estado de aprovação para teste.
- Permitir a atualização posterior mediante evidências documentais.