# 19. CRITÉRIOS DE ACEITAÇÃO DO PLUGIN

| ID | Teste | Resultado esperado |
|---|---|---|
| CA01 | Iniciar projeto sem documentos | Coletar informações essenciais |
| CA02 | Importar protocolo existente | Identificar seções e conteúdo |
| CA03 | Importar estratégias de busca | Preservar expressões originais |
| CA04 | Encontrar informação ausente | Sinalizar pendência |
| CA05 | Encontrar documentos contraditórios | Solicitar decisão humana |
| CA06 | Alterar estratégia aprovada | Criar nova versão |
| CA07 | Gerar PRISMA-S sem buscas executadas | Manter datas e contagens pendentes |
| CA08 | Gerar PRISMA-ScR na fase de protocolo | Classificar resultados como futuros |
| CA09 | Gerar minuta incompleta | Identificar limitações e pendências |
| CA10 | Aprovar protocolo sem buscas definitivas | Permitir quando o planejamento estiver adequado |
| CA11 | Solicitar versão aprovada sem validação humana | Não declarar aprovação |
| CA12 | Retomar projeto | Recuperar estado e histórico disponíveis |
| CA13 | Exportar documento | Gerar arquivo quando houver ferramenta disponível |
| CA14 | Encontrar referência não verificada | Sinalizar necessidade de verificação |
| CA15 | Comparar versões | Apresentar alterações rastreáveis |
| CA16 | Importar apêndices existentes | Preservar identificação e numeração |
| CA17 | Encontrar estratégia logicamente redundante | Apresentar alerta metodológico |
| CA18 | Encontrar ferramenta indisponível | Comunicar limitação sem simular execução |