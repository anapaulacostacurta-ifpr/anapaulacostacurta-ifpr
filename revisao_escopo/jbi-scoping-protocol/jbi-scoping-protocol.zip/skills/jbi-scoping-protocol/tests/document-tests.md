# 13. DOCUMENTOS GERADOS

## 13.1. Documento principal

Protocolo JBI para revisão de escopo.

Nome sugerido:

Protocolo_JBI_Revisao_Escopo_vX_Y.docx

## 13.2. Documentos auxiliares

| Código | Documento |
|---|---|
| A01 | Matriz de definição da pesquisa e PCC |
| A02 | Matriz de critérios de elegibilidade |
| A03 | Estratégias completas de busca |
| A04 | Registro PRISMA-S |
| A05 | Matriz prospectiva PRISMA-ScR |
| A06 | Relatório de buscas-piloto e calibração |
| A07 | Instrumento PRESS, quando adotado |
| A08 | Manual de triagem |
| A09 | Matriz de extração de dados |
| A10 | Plano de análise e síntese |
| A11 | Registro de decisões metodológicas |
| A12 | Histórico de alterações |
| A13 | Relatório de auditoria metodológica |
| A14 | Registro de aprovação dos pesquisadores |
| A15 | Modelo de fluxograma PRISMA |
| A16 | Estado estruturado do projeto |

A numeração dos apêndices deverá ser configurável, respeitando documentos já existentes no projeto.

## 13.3. Formatos de saída

| Formato | Aplicação |
|---|---|
| DOCX | Protocolo e documentos editáveis |
| PDF | Versões consolidadas para distribuição |
| XLSX | Matrizes e registros tabulares |
| CSV | Interoperabilidade de dados |
| JSON | Persistência e transferência de estado |
| Markdown | Documentação e integração com outros sistemas |

A disponibilidade efetiva de cada formato dependerá das ferramentas integradas ao plugin.
# 14. PADRÃO DE FORMATAÇÃO DOCUMENTAL

O plugin deverá permitir a configuração de:

- Tamanho de página.
- Margens.
- Tipografia.
- Espaçamento.
- Hierarquia de títulos.
- Numeração de seções.
- Estilo de referências.
- Cabeçalhos e rodapés.
- Identificação institucional.
- Sumário.
- Numeração de tabelas e figuras.
- Identificação dos apêndices.

Como configuração inicial sugerida:

| Elemento | Padrão |
|---|---|
| Papel | A4 |
| Fonte | Arial |
| Corpo do texto | 11 ou 12 pontos |
| Títulos principais | 14 pontos |
| Espaçamento | 1,5 |
| Margens | 2,5 cm |
| Idioma | Português brasileiro |
| Referências | Configurável |
| Rodapé | Projeto, versão e página |

O padrão deverá ser substituível por modelos institucionais ou editoriais.