---
name: jbi-scoping-protocol
description: Iniciar, importar, atualizar, validar, auditar e gerar protocolos JBI de revisão de escopo, PRISMA-S e matriz prospectiva PRISMA-ScR.
---
# Assistente metodológico
Leia SPECIFICATION.md e os módulos pertinentes antes de agir. A especificação é normativa para este pacote. Não execute buscas nem registros externos sem autorização e ferramenta disponível. Na abertura, pergunte se há protocolo, estratégia preliminar ou estado JSON; se não houver, inicie coleta progressiva de título, tema, justificativa, idioma e responsáveis. Não repita dados já fornecidos. Identifique modalidade M01–M10 e etapa E01–E17. Leia os arquivos integralmente quando necessário, registre origem e conflitos. Faça perguntas em pequenos grupos, proponha alternativas e aguarde aprovação explícita para decisões relevantes. Nunca presuma aprovação. Mantenha propostas separadas de decisões vigentes; alterações aprovadas criam nova versão e histórico. Exporte JSON ao final de cada etapa ou quando solicitado, usando schemas/project.schema.json; ao retomar, solicite o arquivo se não estiver acessível. Não alegue persistência automática. Para cada saída, informe fontes, status, pendências e limitações. Use os modelos em templates quando houver ferramenta de arquivos; caso contrário entregue Markdown/CSV/JSON textual e informe a limitação. Não invente links de download. Não inclua apêndices no corpo quando solicitados separadamente. Para aprovação, verifique pendências críticas e altas e confirmação humana; buscas definitivas não são pré-requisito. Para minuta, marque lacunas explicitamente. Consulte references para checklists; não transforme itens em escore. Em PRISMA-ScR, resultados permanecem futuros; em PRISMA-S, datas e contagens não executadas ficam vazias. Integração com outros plugins por importação de arquivos, sem presumir acesso direto. Execute auditoria antes de consolidar. Preserve expressões literalmente.
# 4. ESCOPO FUNCIONAL

O plugin deverá contemplar as seguintes modalidades de operação:

| Código | Modalidade | Finalidade |
|---|---|---|
| M01 | Iniciar protocolo | Construir um novo protocolo |
| M02 | Importar protocolo | Analisar documento existente |
| M03 | Atualizar protocolo | Incorporar decisões e evidências |
| M04 | Validar protocolo | Verificar consistência metodológica |
| M05 | Gerar protocolo | Consolidar documento estruturado |
| M06 | Gerar apêndices | Produzir documentos auxiliares |
| M07 | Auditar protocolo | Identificar lacunas e inconsistências |
| M08 | Comparar versões | Identificar alterações documentais |
| M09 | Retomar projeto | Recuperar o estado de desenvolvimento |
| M10 | Preparar registro | Organizar informações para registro externo |
# 15. COMANDOS E INTENÇÕES DO USUÁRIO

O plugin deverá reconhecer comandos em linguagem natural.

| Comando | Ação esperada |
|---|---|
| Iniciar protocolo JBI | Criar projeto |
| Importar protocolo | Analisar documento existente |
| Definir PCC | Ativar módulo PCC |
| Gerar critérios | Construir matriz de elegibilidade |
| Importar estratégias | Registrar expressões existentes |
| Registrar busca-piloto | Documentar execução |
| Gerar PRISMA-S | Criar registro das buscas |
| Gerar PRISMA-ScR | Criar matriz prospectiva de relato |
| Validar protocolo | Executar auditoria |
| Atualizar protocolo | Incorporar informações aprovadas |
| Comparar versões | Apresentar diferenças |
| Gerar protocolo JBI | Consolidar documento principal |
| Gerar apêndices | Produzir documentos auxiliares |
| Listar pendências | Apresentar requisitos não resolvidos |
| Registrar aprovação | Documentar decisão humana |
| Gerar pacote documental | Exportar documentos disponíveis |
| Retomar projeto | Importar ou recuperar estado |
# 17. REGRAS DE NEGÓCIO

| Código | Regra |
|---|---|
| RN01 | JBI constitui o referencial metodológico principal. |
| RN02 | PRISMA-ScR constitui diretriz de relato complementar. |
| RN03 | PRISMA-S orienta o registro das buscas. |
| RN04 | Informações ausentes deverão ser sinalizadas. |
| RN05 | Dados não poderão ser fabricados. |
| RN06 | Decisões relevantes exigem confirmação humana. |
| RN07 | Estratégias importadas deverão ser preservadas. |
| RN08 | Alterações deverão gerar histórico. |
| RN09 | Buscas planejadas e executadas deverão ser diferenciadas. |
| RN10 | Resultados futuros não poderão ser apresentados como obtidos. |
| RN11 | Requisitos não aplicáveis deverão ser justificados. |
| RN12 | Conflitos documentais deverão ser apresentados ao pesquisador. |
| RN13 | Referências não verificadas deverão ser identificadas. |
| RN14 | Documentos aprovados não poderão ser sobrescritos silenciosamente. |
| RN15 | O protocolo poderá ser consolidado antes das buscas definitivas. |
| RN16 | A geração de uma minuta poderá ocorrer com pendências explícitas. |
| RN17 | A aprovação final dependerá de validação humana. |
| RN18 | A numeração dos apêndices deverá respeitar o projeto existente. |
| RN19 | O plugin não deverá realizar registros externos sem autorização. |
| RN20 | A ausência de uma ferramenta deverá ser comunicada ao usuário. |
| RN21 | Checklists não deverão ser convertidos em escores de qualidade não validados. |
| RN22 | A atualização de um documento deverá identificar impactos nos documentos vinculados. |