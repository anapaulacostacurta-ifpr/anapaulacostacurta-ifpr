## 8.11. Módulo de auditoria metodológica

Responsável pela verificação de coerência entre os componentes do protocolo.

Deverá identificar:

- Informações ausentes.
- Contradições.
- Decisões sem justificativa.
- Estratégias não validadas.
- Critérios incompatíveis com a pergunta.
- Variáveis sem relação com os objetivos.
- Procedimentos descritos como executados sem evidência.
- Referências não verificadas.
- Divergências entre versões.
- Requisitos metodológicos ainda pendentes.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.