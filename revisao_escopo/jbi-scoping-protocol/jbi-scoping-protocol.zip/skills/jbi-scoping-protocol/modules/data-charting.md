## 8.9. Módulo de extração de dados

Responsável pela criação da matriz de extração.

Campos mínimos sugeridos:

- Identificador do estudo.
- Referência.
- Ano.
- País.
- Objetivo.
- Desenho metodológico.
- Participantes.
- Conceito.
- Contexto.
- Resultados relevantes.
- Limitações.
- Variáveis específicas da revisão.

Cada variável deverá possuir definição operacional e vinculação com os objetivos da pesquisa.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.