## 8.7. Módulo PRISMA-ScR

Responsável pelo mapeamento prospectivo dos requisitos de relato da revisão de escopo.

| Item | Requisito de relato |
|---|---|
| 1 | Título |
| 2 | Resumo estruturado |
| 3 | Justificativa |
| 4 | Objetivos |
| 5 | Protocolo e registro |
| 6 | Critérios de elegibilidade |
| 7 | Fontes de informação |
| 8 | Busca |
| 9 | Seleção das fontes de evidência |
| 10 | Processo de extração de dados |
| 11 | Itens de dados |
| 12 | Avaliação crítica das fontes individuais |
| 13 | Síntese dos resultados |
| 14 | Seleção das fontes de evidência — resultados |
| 15 | Características das fontes de evidência |
| 16 | Avaliação crítica — resultados |
| 17 | Resultados das fontes individuais |
| 18 | Síntese dos resultados |
| 19 | Resumo das evidências |
| 20 | Limitações |
| 21 | Conclusões |
| 22 | Financiamento |

Os itens 12 e 16 deverão ser tratados conforme a aplicabilidade da avaliação crítica.

Os itens relacionados aos resultados da revisão deverão permanecer classificados como futuros, não executados ou não aplicáveis à fase de protocolo.

O módulo deverá gerar uma matriz de correspondência entre os requisitos de relato e as seções do protocolo.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.