## 8.8. Módulo de seleção das evidências

Responsável pelo planejamento da triagem.

Deverá registrar:

- Ferramentas utilizadas.
- Número de revisores.
- Independência das avaliações.
- Procedimentos de calibração.
- Resolução de divergências.
- Critérios operacionais.
- Motivos de exclusão.
- Procedimentos de recuperação de textos completos.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.