# 12. CONTROLE DE VERSIONAMENTO

## 12.1. Convenção sugerida

| Versão | Finalidade |
|---|---|
| v0.1 | Estrutura inicial |
| v0.2 | Revisão metodológica |
| v0.3 | Consolidação preliminar |
| v0.x | Desenvolvimento e calibração |
| v1.0 | Primeira versão aprovada |
| v1.1 | Emenda ou atualização menor |
| v2.0 | Alteração metodológica substancial |

## 12.2. Histórico obrigatório

Cada alteração deverá registrar:

- Versão anterior.
- Nova versão.
- Data.
- Seção alterada.
- Conteúdo anterior.
- Conteúdo atualizado.
- Justificativa.
- Responsável.
- Aprovação.
- Impactos em documentos vinculados.

## 12.3. Emendas ao protocolo

Alterações posteriores à aprovação deverão ser identificadas como emendas, preservando o protocolo originalmente aprovado.