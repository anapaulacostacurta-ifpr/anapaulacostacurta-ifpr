## 8.3. Módulo de elegibilidade

Responsável pela construção de critérios operacionais de inclusão e exclusão.

Cada critério deverá conter:

- Identificador.
- Categoria.
- Descrição.
- Justificativa.
- Regra de aplicação.
- Exemplos limítrofes, quando necessários.
- Status de aprovação.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.