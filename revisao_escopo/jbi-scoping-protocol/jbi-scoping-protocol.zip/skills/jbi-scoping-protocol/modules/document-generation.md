# 13. DOCUMENTOS GERADOS

## 13.1. Documento principal

Protocolo JBI para revisão de escopo.

Nome sugerido:

Protocolo_JBI_Revisao_Escopo_vX_Y.docx

## 13.2. Documentos auxiliares

| Código | Documento |
|---|---|
| A01 | Matriz de definição da pesquisa e PCC |
| A02 | Matriz de critérios de elegibilidade |
| A03 | Estratégias completas de busca |
| A04 | Registro PRISMA-S |
| A05 | Matriz prospectiva PRISMA-ScR |
| A06 | Relatório de buscas-piloto e calibração |
| A07 | Instrumento PRESS, quando adotado |
| A08 | Manual de triagem |
| A09 | Matriz de extração de dados |
| A10 | Plano de análise e síntese |
| A11 | Registro de decisões metodológicas |
| A12 | Histórico de alterações |
| A13 | Relatório de auditoria metodológica |
| A14 | Registro de aprovação dos pesquisadores |
| A15 | Modelo de fluxograma PRISMA |
| A16 | Estado estruturado do projeto |

A numeração dos apêndices deverá ser configurável, respeitando documentos já existentes no projeto.

## 13.3. Formatos de saída

| Formato | Aplicação |
|---|---|
| DOCX | Protocolo e documentos editáveis |
| PDF | Versões consolidadas para distribuição |
| XLSX | Matrizes e registros tabulares |
| CSV | Interoperabilidade de dados |
| JSON | Persistência e transferência de estado |
| Markdown | Documentação e integração com outros sistemas |

A disponibilidade efetiva de cada formato dependerá das ferramentas integradas ao plugin.