## 8.4. Módulo de estratégias de busca

Responsável pela documentação das expressões de busca.

Deverá permitir:

- Organização por blocos conceituais.
- Vocabulários controlados.
- Termos livres.
- Sinônimos.
- Operadores booleanos.
- Truncamentos.
- Operadores de proximidade.
- Adaptação de sintaxe por plataforma.
- Estratégias principais e complementares.
- Controle de versões.
- Identificação de redundâncias e relações de inclusão lógica.

As estratégias originais importadas deverão ser preservadas literalmente.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.