## 8.5. Módulo de buscas-piloto e calibração

Responsável pelo registro dos testes das estratégias.

Deverá permitir integração com plugins especializados em calibração bibliográfica, quando disponíveis.

Dados mínimos:

| Campo | Registro |
|---|---|
| Identificador da estratégia | Obrigatório |
| Base e plataforma | Obrigatório |
| Versão da expressão | Obrigatório |
| Data de execução | Quando executada |
| Expressão efetivamente executada | Quando executada |
| Filtros aplicados | Quando executada |
| Total recuperado | Quando executada |
| Estudos de referência recuperados | Quando avaliados |
| Problemas identificados | Quando existentes |
| Alterações propostas | Quando existentes |
| Justificativa | Obrigatória para alterações |
| Decisão humana | Obrigatória para aprovação |

O módulo não deverá simular resultados de buscas não executadas.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.