## 8.1. Módulo de delimitação da pesquisa

Responsável pela estruturação do problema, justificativa, objetivos e escopo.

Saídas:

- Matriz de definição da pesquisa.
- Pergunta principal.
- Perguntas secundárias.
- Objetivos.
- Registro de decisões.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.