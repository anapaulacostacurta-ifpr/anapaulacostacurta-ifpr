## 8.10. Módulo de síntese e apresentação

Responsável pelo planejamento das categorias de análise e formas de apresentação das evidências.

Não deverá gerar conclusões antes da disponibilidade dos dados.

Ao concluir, apresente proposta, evidências, pendências e solicite confirmação; exporte estado atualizado.