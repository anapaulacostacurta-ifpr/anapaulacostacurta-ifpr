# 3. REFERENCIAIS METODOLÓGICOS

| Referencial | Aplicação no plugin | Natureza |
|---|---|---|
| JBI Manual for Evidence Synthesis | Estrutura e metodologia da revisão de escopo | Referencial principal |
| PRISMA-ScR | Planejamento dos requisitos de relato da revisão | Diretriz complementar |
| PRISMA-S | Documentação das estratégias de busca | Diretriz complementar |
| PRESS | Revisão por pares das estratégias eletrônicas de busca | Instrumento opcional |
| PRISMA 2020 | Apoio à representação do fluxo de seleção das evidências | Instrumento complementar |
| PCC | Estruturação da pergunta e dos critérios de elegibilidade | Estrutura conceitual |

## 3.1. Hierarquia metodológica

O plugin deverá considerar a metodologia JBI como referencial principal para a elaboração do protocolo.

O PRISMA-ScR deverá ser utilizado prospectivamente para antecipar requisitos de relato da revisão concluída.

O PRISMA-S deverá orientar a documentação das buscas, sem substituir os procedimentos metodológicos definidos pelo JBI.

O plugin não deverá apresentar o PRISMA-ScR como uma diretriz específica de elaboração de protocolos.

O PRISMA-P, desenvolvido para protocolos de revisões sistemáticas, não deverá ser imposto automaticamente como requisito de protocolos de revisões de escopo.

## 3.2. Atualização dos referenciais

O plugin deverá permitir a atualização das referências metodológicas utilizadas, registrando:

- Documento consultado.
- Versão ou edição.
- Data de publicação ou atualização.
- Data de consulta.
- Endereço eletrônico.
- Alterações metodológicas relevantes.
# 7. ESTRUTURA DO PROTOCOLO JBI

O documento gerado deverá utilizar a seguinte estrutura-base, adaptável às exigências institucionais ou editoriais.

## 7.1. Elementos de identificação

- Título.
- Autores.
- Afiliações.
- Autor correspondente.
- Identificação da versão.
- Data.
- Status documental.
- Informações de registro, quando disponíveis.

O título deverá identificar explicitamente o documento como protocolo de revisão de escopo.

## 7.2. Resumo

Quando aplicável ao formato de publicação, o resumo deverá contemplar:

- Objetivo.
- Introdução ou contextualização.
- Critérios de inclusão.
- Métodos.
- Palavras-chave.

## 7.3. Introdução

A introdução deverá apresentar:

- Contextualização do tema.
- Definição dos conceitos centrais.
- Relevância científica.
- Estado geral do conhecimento.
- Lacunas existentes.
- Justificativa para a realização de uma revisão de escopo.
- Resultados de buscas preliminares por revisões semelhantes, quando realizadas.
- Justificativa da originalidade ou complementaridade da revisão.

## 7.4. Objetivos

### Objetivo geral

Deverá expressar claramente a finalidade de mapeamento das evidências.

### Objetivos específicos

Deverão estar vinculados à pergunta de pesquisa e aos dados que serão extraídos.

## 7.5. Pergunta de pesquisa

A pergunta deverá ser construída com base na estrutura PCC.

| Elemento | Definição |
|---|---|
| P — Population | População ou participantes de interesse |
| C — Concept | Conceito central investigado |
| C — Context | Contexto de aplicação ou investigação |

Quando a população não constituir um elemento restritivo relevante, essa condição deverá ser explicitada e justificada.

O plugin deverá permitir perguntas secundárias, desde que coerentes com a pergunta principal.

## 7.6. Critérios de elegibilidade

### Participantes

Definição das populações ou participantes elegíveis.

### Conceito

Definição operacional do conceito investigado.

### Contexto

Delimitação dos ambientes, setores, instituições ou condições de interesse.

### Tipos de fontes de evidência

Definição das categorias de documentos e desenhos de estudo elegíveis.

### Critérios adicionais

Quando aplicáveis:

- Idiomas.
- Período de publicação.
- Tipos documentais.
- Literatura cinzenta.
- Condições de acesso.
- Critérios específicos de inclusão e exclusão.

Restrições deverão ser justificadas metodologicamente.

## 7.7. Métodos

### 7.7.1. Referencial metodológico

Identificação da metodologia JBI e das diretrizes complementares adotadas.

### 7.7.2. Estratégia de busca

Planejamento da busca conforme a abordagem JBI, contemplando, quando aplicável:

1. Busca inicial limitada em fontes apropriadas.
2. Análise dos termos presentes nos títulos, resumos e vocabulários de indexação.
3. Desenvolvimento e adaptação das estratégias para as fontes selecionadas.
4. Execução das buscas abrangentes.
5. Busca complementar nas referências das fontes relevantes.

O plugin deverá registrar adaptações justificadas a essa abordagem.

### 7.7.3. Fontes de informação

Identificação das bases bibliográficas, plataformas, repositórios e outras fontes.

### 7.7.4. Seleção das fontes de evidência

Definição dos procedimentos de:

- Importação dos registros.
- Deduplicação.
- Triagem de títulos e resumos.
- Avaliação de textos completos.
- Registro dos motivos de exclusão.
- Resolução de divergências.
- Calibração dos revisores.
- Consolidação do fluxo de seleção.

### 7.7.5. Extração de dados

Definição do instrumento de extração, das variáveis, dos responsáveis e do procedimento de teste-piloto.

### 7.7.6. Avaliação crítica

O plugin deverá solicitar a definição sobre a realização ou não de avaliação crítica das fontes de evidência.

Caso seja realizada, deverão ser informados os objetivos, instrumentos e procedimentos.

A avaliação crítica não deverá ser imposta como requisito obrigatório de toda revisão de escopo.

### 7.7.7. Análise e apresentação dos resultados

Planejamento das formas de organização, mapeamento e síntese das evidências.

O plugin deverá permitir:

- Síntese descritiva.
- Distribuições de frequência.
- Mapeamento conceitual.
- Categorização temática.
- Tabelas.
- Gráficos.
- Matrizes.
- Identificação de lacunas de pesquisa.

## 7.8. Declarações complementares

- Contribuição dos autores.
- Financiamento.
- Conflitos de interesse.
- Agradecimentos.
- Registro do protocolo.
- Disponibilidade de materiais.
- Declarações éticas, quando aplicáveis.
- Alterações posteriores ao protocolo.

## 7.9. Referências

O plugin deverá organizar exclusivamente referências identificadas ou verificadas.

Referências não verificadas deverão ser sinalizadas.

## 7.10. Apêndices

O protocolo deverá permitir a vinculação de documentos auxiliares, sem duplicação desnecessária de conteúdo.