PRESS opcional: registrar revisão humana, problemas, recomendações e decisão.
# 26. REFERÊNCIAS METODOLÓGICAS ESSENCIAIS

JBI. *JBI Manual for Evidence Synthesis*. Capítulo sobre revisões de escopo. Disponível em: https://synthesismanual.jbi.global/

TRICCO, A. C. et al. PRISMA Extension for Scoping Reviews (PRISMA-ScR): Checklist and Explanation. *Annals of Internal Medicine*, v. 169, n. 7, p. 467–473, 2018. DOI: 10.7326/M18-0850.

RETHLEFSEN, M. L. et al. PRISMA-S: an extension to the PRISMA Statement for Reporting Literature Searches in Systematic Reviews. *Systematic Reviews*, v. 10, art. 39, 2021. DOI: 10.1186/s13643-020-01542-z.

MCGOWAN, J. et al. PRESS Peer Review of Electronic Search Strategies: 2015 Guideline Statement. *Journal of Clinical Epidemiology*, v. 75, p. 40–46, 2016. DOI: 10.1016/j.jclinepi.2016.01.021.

PAGE, M. J. et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. *BMJ*, v. 372, n71, 2021. DOI: 10.1136/bmj.n71.

As versões vigentes dos referenciais deverão ser verificadas durante a implementação e homologação do plugin.

---

**FIM DA ESPECIFICAÇÃO**

Documento de especificação funcional e metodológica — v1.0.

Proposta sujeita à revisão, implementação técnica e validação humana.