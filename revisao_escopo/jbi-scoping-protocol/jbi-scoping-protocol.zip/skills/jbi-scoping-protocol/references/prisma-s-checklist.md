## 8.6. Módulo PRISMA-S

Responsável pela criação e atualização do registro das buscas.

Deverá contemplar os 16 itens do PRISMA-S:

| Nº | Requisito |
|---|---|
| 1 | Bases de dados e plataformas |
| 2 | Busca simultânea em múltiplas bases |
| 3 | Registros de estudos |
| 4 | Recursos online e navegação |
| 5 | Busca por citações |
| 6 | Contatos com pesquisadores |
| 7 | Outros métodos |
| 8 | Estratégias completas |
| 9 | Limites e restrições |
| 10 | Filtros de busca |
| 11 | Estratégias de trabalhos anteriores |
| 12 | Atualização das buscas |
| 13 | Datas das buscas |
| 14 | Revisão por pares |
| 15 | Total de registros recuperados |
| 16 | Deduplicação |

Para cada item, registrar a situação, a evidência documental, a seção correspondente, as pendências e o responsável.