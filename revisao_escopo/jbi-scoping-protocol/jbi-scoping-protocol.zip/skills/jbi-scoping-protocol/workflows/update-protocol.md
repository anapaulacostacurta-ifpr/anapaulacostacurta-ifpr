# update-protocol
Aplicar E17. Identificar estado e fontes, executar módulos pertinentes, registrar pendências e decisões, exportar JSON.
# 9. FLUXO OPERACIONAL

| Etapa | Processo | Produto |
|---|---|---|
| E01 | Inicialização | Registro do projeto |
| E02 | Importação documental | Inventário de documentos |
| E03 | Delimitação | Matriz de pesquisa |
| E04 | Estruturação PCC | Pergunta de pesquisa |
| E05 | Elegibilidade | Matriz de critérios |
| E06 | Planejamento das buscas | Estratégias preliminares |
| E07 | Calibração, quando realizada | Relatório de testes |
| E08 | Documentação PRISMA-S | Registro das buscas |
| E09 | Planejamento da seleção | Procedimento de triagem |
| E10 | Planejamento da extração | Matriz de dados |
| E11 | Planejamento da síntese | Plano de análise |
| E12 | Mapeamento PRISMA-ScR | Matriz de correspondência |
| E13 | Auditoria | Relatório de pendências |
| E14 | Consolidação | Minuta do protocolo |
| E15 | Validação humana | Versão aprovada |
| E16 | Geração documental | Protocolo e apêndices |
| E17 | Atualizações posteriores | Emendas e novas versões |

O fluxo deverá permitir retorno a etapas anteriores, preservando as versões e decisões registradas.

A existência de buscas definitivas, resultados de triagem ou dados extraídos não deverá ser exigida para a aprovação de um protocolo prospectivo.