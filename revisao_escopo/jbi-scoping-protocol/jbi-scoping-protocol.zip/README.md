# JBI Scoping Review Protocol Builder
Versão 1.0.0 — pacote candidato à homologação.
Importe o ZIP pelo mecanismo de plugins disponível no ChatGPT, se compatível. Se não aceitar, use o Plugin Creator para adaptar a estrutura, fornecendo SKILL.md e arquivos associados. A instalação e execução não foram testadas. Não há serviço externo, persistência automática nem integração direta. Modelos são próprios, não oficiais JBI.
