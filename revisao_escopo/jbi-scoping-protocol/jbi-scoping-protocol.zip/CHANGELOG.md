# 1.0.0
Pacote inicial de instruções, modelos, esquemas e testes não executados.
