# Justificativa sem antecipação de buscas ou resultados

Regra operacional definida pelo usuário. Aplicar antes de entrevistar, redigir ou consolidar a justificativa; prevalece sobre instruções que possam pressupor buscas ou exigir lacuna conhecida.

## Entrevista adaptativa

Partir da necessidade de conhecimento do pesquisador, aproveitando documentos e respostas já disponíveis. Perguntar uma coisa por vez e aguardar. Não pressupor busca realizada, revisões identificadas ou lacuna comprovada. Explorar somente o que faltar:
- o que precisa compreender sobre o tema;
- informações a reunir, descrever ou organizar;
- características, conceitos, relações e contextos a examinar;
- relevância dessa organização e seus beneficiários;
- contribuição pretendida;
- adequação da revisão de escopo à finalidade.

Não transformar essa lista em questionário fixo. Não exigir “qual é a lacuna da literatura?”, “quais estudos você já conhece?” ou “o que as revisões anteriores não analisaram?” para avançar. Não pedir estudos ou lacunas conhecidos. Se estudos ou revisões forem apresentados espontaneamente, distinguir referência indicada, material recuperado e conteúdo efetivamente lido; uma citação ou título não comprova exame do conteúdo.

## Três elementos distintos

1. **Necessidade de conhecimento:** o que se pretende esclarecer ou organizar e por que merece investigação. Pode ser construído com a entrevista, sem comprovar novidade científica.
2. **Situação das sínteses existentes:** depende de busca e exame documentados, incluindo revisões sistemáticas, revisões de escopo e mapeamentos sistemáticos quando pertinentes ao campo. Não é um resultado a presumir nem uma pergunta sobre o repertório bibliográfico pessoal do usuário.
3. **Lacunas identificadas pela revisão:** só podem ser apresentadas como achados após análise das evidências, se sustentadas por elas e com limites de cobertura e elegibilidade explícitos.

## Quando ainda não houve verificação de sínteses

Registrar “verificação de sínteses existentes: planejada/pendente”. Não bloquear a entrevista nem a justificativa provisória. Redigir tema/contexto, necessidade de conhecimento, contribuição pretendida e adequação da ScR, em linguagem prospectiva. Se o estado da verificação não estiver documentado, registrar “não informado”, sem dizer que uma busca ocorreu ou que não ocorreu. Não perguntar sobre estudos conhecidos para preencher esse estado.

Não afirmar ineditismo, escassez de estudos ou ausência de sínteses sem evidência examinada. Não usar “a literatura demonstra”, “poucos estudos investigam”, “não existem revisões”, “as revisões anteriores não contemplam” nem equivalentes sem suporte verificável.

Exemplo de formulação prospectiva, a adaptar ao projeto e submeter à validação: “A revisão parte da necessidade de compreender e organizar informações sobre [fenômeno]. Pretende-se identificar [características] e examinar [relações] pertinentes à pergunta proposta. Será planejada a verificação de sínteses existentes para situar a contribuição pretendida e refinar a justificativa.”

Se essa verificação já estiver planejada, escrever “Está prevista a verificação”, em vez de sugerir que ela ainda será planejada. Ajustar o tempo verbal à situação real. Não inventar planejamento aceito: marcar como proposta quando ainda não decidido.

## Quando uma busca preliminar é informada

Aprofundar apenas se o documento ou o usuário informar que a busca foi realizada. Antes de redigir afirmações sobre resultados, esclarecer objetivo, fontes e plataformas, datas, estratégias/limites, arquivos e documentação disponíveis, e quais materiais foram efetivamente examinados. Perguntar somente pelos campos faltantes, um por vez. Isso não autoriza perguntar quais estudos o usuário já conhece nem pressupor o resultado de uma busca.

Distinguir busca por sínteses anteriores de busca exploratória de termos, calibragem, busca final e triagem. Primeira string ou exportação isolada não comprovam que sínteses anteriores foram examinadas. Manter conclusões limitadas ao universo recuperado e examinado; não generalizar ausência de resultados à inexistência de estudos ou revisões. Se a documentação não permitir conferir uma afirmação, qualificá-la como relato não verificado ou manter a afirmação pendente.

## Conferência e rastreabilidade

Antes de consolidar cada versão, conferir explicitamente:
- nenhum procedimento planejado foi descrito como executado;
- nenhuma expectativa ou contribuição pretendida foi apresentada como achado;
- nenhuma referência indicada foi tratada como conteúdo examinado;
- nenhuma afirmação de novidade, escassez ou ausência foi incluída sem suporte;
- necessidade, situação das sínteses e lacunas pós-análise estão separados.

Se faltar informação, manter texto provisório e pendência identificada, sem fabricar resultado. Atualizar a justificativa quando novas evidências forem efetivamente examinadas, registrando versão/data, trecho anterior, mudança, motivo, fonte/documentação e impacto metodológico. Sugestões permanecem propostas até decisão explícita da equipe.

Preservar documento inicial obrigatório, perguntas individuais, proibição de consulta ao histórico/memórias e aprovação prévia de consultas externas com validação de cada URL e finalidade. Esta referência não autoriza busca automática.
