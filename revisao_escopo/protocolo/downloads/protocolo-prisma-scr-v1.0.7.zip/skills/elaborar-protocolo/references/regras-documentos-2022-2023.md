# Orientações dos documentos fornecidos em 12/11/2026

Síntese interna em paráfrase, baseada exclusivamente nos PDFs anexados nesta conversa. Não equivale a consulta externa atual, certificação ou reprodução integral. Não incorporar dados pessoais ou dados do projeto desta usuária a outras pesquisas.

## Fontes lidas

1. Lely, Justine; Morris, Hailey C.; Sasson, Noa; Camarillo, Nathan D.; Livinski, Alicia A.; Butera, Gisela; Wickstrom, Jordan. How to Write a Scoping Review Protocol: Guidance and Template. Arquivo FINAL 05-23-23, 3 páginas. Os dois arquivos de template enviados são cópias idênticas (SHA-256 852af4e6e79a27311618cd5cd0d60f1ea05d694eb96dbe67e9ece5eacfc59aa2). Não é o mesmo template JBI 2024. Não atribuir autoria institucional JBI a este modelo.
2. Peters MDJ et al. Best practice guidance and reporting items for the development of scoping review protocols. JBI Evidence Synthesis. 2022;20(4):953–968. DOI transcrito do PDF: 10.11124/JBIES-21-00242. Tabela 1 e apêndice adaptam itens PRISMA-P para protocolos ScR; essa adaptação não transforma PRISMA-P integral em exigência universal para ScR.
3. Munn Z et al. What are scoping reviews? Providing a formal definition of scoping reviews as a type of evidence synthesis. JBI Evidence Synthesis. 2022;20(4):950–952. DOI transcrito do PDF: 10.11124/JBIES-21-00483.

## Aplicação e escolha de modelo

Antes das perguntas metodológicas, pedir o documento do Pesquisa | Do Tema à String. Recomendar também o template em arquivo. Se houver modelos concorrentes (por exemplo, Lely 2023 e JBI 2024), identificar as diferenças e perguntar qual regerá a estrutura; não mesclar silenciosamente. Uma escolha já explícita não precisa ser confirmada novamente. Usar estas orientações para completar o planejamento sem repetir definições do documento inicial.

Nenhuma leitura externa é necessária para usar esta síntese interna. Para verificar links, versões atuais ou referências adicionais, apresentar cada URL, finalidade e obter validação do endereço e aprovação explícita antes de acesso. Não utilizar históricos nem memórias pessoais do usuário.

## Princípios metodológicos

- ScR identifica sistematicamente e descreve a amplitude das evidências, conceitos, características, formas de pesquisar e lacunas. Justificar esse desenho pela pergunta; não tratar como revisão rápida informal ou revisão de eficácia por padrão (Munn 2022, pp. 950–951).
- Planejar protocolo antes da execução; se já houve execução, informar seu estágio real. Predefinir objetivo, perguntas, critérios e processos, detalhando emendas datadas e justificadas (Peters 2022, pp. 954–955 e apêndice).
- Tornar o objetivo específico quanto ao que será extraído e apresentado. “Mapear a literatura” sozinho pode ser insuficiente. Garantir alinhamento título → objetivos → perguntas → critérios → extração → apresentação (Peters, pp. 955, 959–961).
- PCC é adequado a ScR, sem impor PICO. O modelo Lely menciona população/intervenção/exposição/desfechos na orientação de objetivo; adaptar esses exemplos à pergunta e explicar o uso de PCC. Nem toda revisão tem população humana; justificar componentes pertinentes.
- Justificar todas as restrições e definir termos operacionalmente. Prever informação ambígua, consenso de interpretação e diferentes relatos do mesmo estudo. A inclusão conjunta de primários e revisões exige plano para evitar dupla contagem; não impor uma solução única (Peters, pp. 961–962).
- Identificar método de condução e diretrizes de relato separadamente. PRISMA-ScR orienta o manuscrito da revisão; a orientação de Peters 2022 é específica do planejamento/relato de protocolos. Não declarar adesão integral não verificada.

## Estrutura do modelo Lely e colaboradores de 2023

1. Título: identificar protocolo de revisão de escopo e representar objetivo.
2. Autores/afiliações; autor correspondente com contato conforme destino de publicação. Não inventar ou exigir divulgação pública de dados pessoais na conversa; campos podem ficar pendentes.
3. Resumo: Introdução (tema, justificativa, objetivo); Métodos e análise (método, busca, fontes e limites, triagem/extração, pilotos e revisores, análise); Ética e disseminação; até cinco palavras-chave em ordem alfabética. O PDF não fixa limite de 250 palavras: esse limite pertence ao template JBI 2024 previamente usado, não deve ser atribuído a Lely. Conferir exigência editorial escolhida.
4. Introdução: contexto, conceitos, necessidade de conhecimento e justificativa do desenho; objetivo e questões alinhados. O conteúdo bibliográfico da seção pode usar materiais fornecidos e consultas autorizadas, mas a entrevista não deve perguntar estudos, revisões antecedentes ou lacunas conhecidos. Construir a necessidade por perguntas sobre dúvida, motivação, relevância e conhecimento que se pretende organizar. Não exigir leitura prévia nem antecipar achados.
5. Métodos: referencial de condução, orientação para escrever o protocolo e diretriz PRISMA-ScR para o relatório final.
6. Elegibilidade: inclusão/exclusão justificadas; limites, casos ambíguos e interpretação compartilhada.
7. Fontes e busca: responsável pela estratégia; bases/plataformas e outras fontes; termos, cobertura, datas planejadas versus executadas, limites e software; estratégia integral para pelo menos uma base; informar se PRESS será empregado, sem torná-lo obrigação automática.
8. Seleção: descrever separadamente título/resumo e texto completo; critérios, pilotos, quantidade de revisores e independência, discordâncias, casos incertos, software e motivos de exclusão. Não inventar tamanhos de piloto; definir com equipe.
9. Extração/charting: formulário, campos e regras de codificação documentadas; piloto, revisores, independência/conferência, divergências, informações ausentes e software. O PDF usa “friend studies” sem defini-lo: sinalizar ambiguidade; planejar múltiplos relatos/estudos relacionados sem atribuir definição não fornecida à expressão.
10. Síntese/apresentação: limpeza dos dados e software, fluxograma, análise e apresentação previstas para cada item de extração, tabelas/figuras/mapas e participação de interessados quando pertinente.
11. Ética/disseminação: justificar necessidade ou dispensa de apreciação ética conforme atividades efetivamente planejadas e regras aplicáveis; não declarar dispensa automática. Definir colaboradores, usuários do conhecimento e produtos/canais de disseminação.
12. Conclusão do PROTOCOLO: retomar objetivos, necessidade de conhecimento e contribuição pretendida em linguagem prospectiva; não anunciar lacunas identificadas antes da execução e análise da revisão. É permitida neste modelo; não escrever achados nem conclusões empíricas de revisão ainda não executada. Isso difere de excluir resultados/conclusões do resumo de protocolo JBI.
13. Apoio/financiamento: nomes, papéis, projetos/números se existentes; confirmar ausência quando declarada.
14. Conflitos, agradecimentos e referências conforme destino; não presumir ausência de conflitos.

## Regras complementares de Peters 2022

- Registrar título/atualização, registro se existente, autores e contribuições, apoio/financiamento, emendas, justificativa e questões; considerar condições do periódico/repositório.
- Busca: fontes pertinentes ao campo, cobertura e limites justificados; plano de busca complementar/iterativa documentada; participação de profissional de informação quando prevista. Não converter sugestão em obrigação universal. Estratégia anexada deve permitir repetição.
- Seleção: explicitar revisores, independência/conferência, piloto e resolução de divergências; registrar exclusões e representação do fluxo (pp. 963–964). Não apresentar IA como revisor humano independente.
- Extração: campos vinculados à pergunta, formulário preliminar, piloto e refinamentos documentados, papéis e discordâncias (p. 964).
- Avaliação crítica não é automática. Se prevista, justificar, informar instrumento e finalidade; segundo este artigo, seus resultados não devem determinar exclusão em ScR (p. 964). Se equipe propuser exclusão por qualidade, apontar a tensão e discutir adequação do desenho.
- Análise geralmente descritiva, com frequências, percentuais, tabelas e mapas. O artigo distingue mapeamento/codificação descritiva de síntese interpretativa temática e alerta para esta última sem avaliação metodológica (Tabela 1, p. 958; pp. 964–965). Não recomendar análise temática automaticamente; justificar natureza, alcance e compatibilidade com objetivo/método.
- Metanálise, avaliação de metaviés e GRADE não são requisitos padrão de ScR; não transportar itens de revisão de efeitos sem justificativa. Não declarar que uma fonte de 2022 comprova o estado atual de ferramentas ou plataformas.

## Auditoria antes da entrega

Verificar: modelo escolhido e versão; cadeia de coerência; critérios e limites justificados; busca reproduzível proposta versus executada; plano real de seleção/extração e pilotos; dados ausentes/ambíguos e múltiplos relatos; análise prevista para cada campo; ética/disseminação; financiamento/contribuições/conflitos; referências lidas; apêndices e emendas. Marcar não aplicável com justificativa e pendente quando faltar decisão. Não inventar resultados, datas, números ou aprovações. Indicar fonte e página ao fundamentar recomendações nestes documentos, sem alegar consulta de referências apenas citadas por eles.
\n## Esclarecimento operacional incorporado em 13/11/2026\n\nA orientação de contextualizar o desconhecido na introdução não exige antecipar achados. No protocolo, fundamentar o racional na leitura preliminar e delimitar o que se pretende esclarecer. Uma lacuna sugerida por essa leitura, quando houver, é provisória e tem alcance limitado. Após a revisão, relatar somente as lacunas sustentadas pelo corpus e reconhecer limites de cobertura; não pressupor que serão encontradas. Este esclarecimento é uma regra operacional solicitada pelo usuário, não citação literal nem alegação de nova consulta aos artigos.\n

## Aplicação na entrevista — atualização de 13/11/2026

Não transformar o conteúdo bibliográfico previsto nos modelos em cobrança de estudos conhecidos ou lacuna conhecida ao usuário. Conduzir perguntas para construir a necessidade de conhecimento e sua relevância. Usar fontes espontaneamente fornecidas sem solicitá-las como pré-requisito; quando faltar suporte bibliográfico para a redação, complementar em tarefa distinta e somente mediante autorização para consultas externas. A necessidade formulada não comprova escassez de estudos, novidade nem lacuna científica. Regra operacional solicitada pelo usuário, preservando a distinção entre fundamentação e resultados da revisão.

## Complemento operacional — justificativa prospectiva

Seguir [justificativa sem antecipação](justificativa-sem-antecipacao.md). Referências indicadas não equivalem a conteúdos examinados. A situação das sínteses depende de verificação documentada, que pode estar planejada ou pendente sem impedir justificativa provisória. Não converter texto exemplar de um template em declaração de busca executada. Reexaminar tempos verbais e suporte das afirmações antes de consolidar; atualizar com rastreabilidade quando houver novas evidências. Regra solicitada pelo usuário, sem atribuir nova consulta às fontes originais.
