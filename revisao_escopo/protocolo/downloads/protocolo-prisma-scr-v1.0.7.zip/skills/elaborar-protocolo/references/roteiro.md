# Roteiro adaptativo e estrutura

Base estrutural: template JBI de 2024 consultado em 12/11/2026. Este arquivo é orientação interna, não substitui fontes oficiais ou consulta atual. Não reproduza o template integralmente.

## Regras de acesso

Não consultar históricos, memórias ou contexto pessoal do usuário. Usar apenas dados desta conversa. Antes de qualquer consulta externa, apresentar cada URL completo, fonte e finalidade; solicitar validação do link E aprovação da consulta e aguardar confirmação explícita de ambos. Novo endereço ou finalidade exige nova autorização. Sem aprovação, marcar verificação externa como pendente e prosseguir apenas com materiais fornecidos e internos.

## Template anexado

Solicite também, de preferência em DOCX, o modelo do template. Indique https://guides.library.kumc.edu/Protocols/ScR-templates-examples para o usuário obtê-lo, sem acesso automático. Leia nome, versão e instruções do modelo recebido e use sua estrutura; não presuma equivalência ao roteiro de 2024. Se ausente, recomende o envio. Por opção do usuário, avance provisoriamente com o roteiro interno e marque a conferência como pendente. Toda consulta à página e aos links de download exige validação do endereço e aprovação explícita antes do acesso.

## Pré-requisito obrigatório

Antes de qualquer pergunta, solicitar o documento gerado pelo plugin Pesquisa | Do Tema à String e aguardar seu envio. Se já estiver disponível e legível, ler sem pedir novamente. Não começar do zero; aproveitar suas definições e perguntar somente pelas lacunas após a leitura. Arquivo ilegível ou incorreto: solicitar a versão correta antes de entrevistar.

## Entrevista

1. Diagnóstico: tema, problema, contribuição, finalidade, estágio, adequação do desenho; se ambíguo com outro tipo de revisão, esclareça antes de fixar o método. Identifique procedimentos já executados.
2. Identificação: título provisório, autores, afiliações, papéis, finalidade acadêmica, recursos, cronograma, registro/publicação pretendidos.
3. Introdução: construir contextualização e necessidade de conhecimento a partir do documento inicial e de perguntas sobre o que se deseja compreender, motivação, relevância, beneficiários e informações a organizar. Não perguntar quais estudos, revisões ou lacunas o pesquisador conhece, nem exigir leitura prévia. Aproveitar fontes espontaneamente fornecidas. A fundamentação bibliográfica será complementada separadamente com materiais disponíveis ou consultas externas autorizadas. Alinhar contribuição pretendida, pergunta PCC e objetivos; não antecipar lacunas que dependem do corpus.
4. Pergunta e objetivos: formular pergunta principal e subperguntas preferencialmente com PCC (População/Participantes, Conceito e Contexto), com adaptações justificadas e sem impor PICO. Definir objetivo geral e específicos pertinentes; alinhar título, pergunta, objetivos e critérios. Não converter lacunas previstas em resultados garantidos.
5. Elegibilidade: participantes, conceito, contexto, tipos de evidência/publicação, idiomas, período, exclusões e justificativas. Trate revisões, eventos, teses, literatura cinzenta e múltiplos relatos conforme a pergunta. Não adote exemplos clínicos por padrão.
6. Busca: bases e plataformas, fontes complementares, literatura cinzenta, referências e citações; termos livres e vocabulários controlados pertinentes; busca exploratória, desenvolvimento, adaptação, teste, revisão e atualização. Discuta as três etapas de busca sugeridas pelo template e sua implementação na área. Prepare estratégia integral para pelo menos uma base no Apêndice I. Inclua plataforma, campos, lógica booleana, truncamento, limites e justificativas, data e contagem apenas se executada. Planeje logs e exportações. Não declare teste que não ocorreu.
7. Seleção: gestão de registros, deduplicação, piloto, título/resumo, texto completo, revisores e independência, divergências, recuperação de textos, motivos de exclusão e fluxograma. Diferencie registros, relatórios e estudos. Não invente totais.
8. Extração: formulário, variáveis ligadas à pergunta, dicionário, piloto, responsáveis, conferência, divergências, modificações e dados ausentes/contato com autores quando pertinente. Diferencie dados textuais de codificação interpretativa. Discuta necessidade e finalidade de avaliação crítica e instrumentos se adotada. Prepare Apêndice II conforme pertinência.
9. Análise/apresentação: descrição, categorias, síntese narrativa, tabelas, gráficos e mapas; relacione produtos a perguntas e variáveis. Não extrapole causalidade ou eficácia.
10. Transparência: registro, disponibilização, versões, emendas, compartilhamento, uso de IA e supervisão humana; agradecimentos, financiamento e papel dos financiadores, contribuições autorais, conflitos e declarações pertinentes. Pergunte sobre envolvimento de usuários do conhecimento quando relevante, sem convertê-lo em exigência universal. Diferencie aspectos éticos de revisão documental de atividades com participantes que possam exigir análise específica.
11. Resumo por último: até 250 palavras para protocolo, com Objetivo, Introdução, Critérios de inclusão e Métodos. Sem resultados e conclusões reservados à revisão concluída. Até cinco palavras-chave em ordem alfabética, separadas por ponto e vírgula; não confunda palavras-chave editoriais com termos da busca.

## Sequência de entrega conforme template

- Título (identificar protocolo de revisão de escopo), autores e afiliações.
- Resumo estruturado e palavras-chave.
- Introdução, justificativa e objetivo.
- Pergunta(s) de revisão.
- Critérios de inclusão: participantes, conceito, contexto e tipos de fontes; explicitar exclusões pertinentes.
- Métodos: referencial de condução e situação de registro.
- Estratégia de busca.
- Seleção das fontes de evidência.
- Extração de dados; avaliação crítica se adotada, com justificativa.
- Análise e apresentação dos dados.
- Agradecimentos.
- Financiamento.
- Declarações pertinentes.
- Contribuições dos autores.
- Conflitos de interesse.
- Referências efetivamente verificadas.
- Apêndice I: estratégia completa de busca para ao menos uma base e limites planejados. Se não executada, registrar isso em vez de inventar data ou quantidade.
- Apêndice II: instrumento novo/modificado de extração quando aplicável; para ferramenta padronizada sem modificação, citar conforme orientação do template.

Como complementos claramente identificados: cronograma, ficha de decisões, log de emendas, matriz de coerência e correspondência com PRISMA-ScR. Na correspondência, diferencie itens planejáveis no protocolo dos que dependem da revisão executada. Não preencher paginação ou status de conformidade sem conferir a versão final.

## Comandos úteis

“Iniciar protocolo”: solicitar o documento do Pesquisa | Do Tema à String; somente após a leitura, começar o diagnóstico.
“Continuar entrevista”: verificar se o documento inicial já foi lido nesta pesquisa; se ausente, solicitá-lo antes de perguntas. Com ele disponível, recuperar a ficha e perguntar a próxima lacuna.
“Mostrar decisões”: apresentar ficha e pendências.
“Revisar coerência”: auditar a cadeia metodológica sem mudar decisões.
“Gerar versão preliminar”: redigir com [PENDENTE] nos campos faltantes.
“Registrar emenda”: documentar mudança, justificativa e impacto.

## Orientações adicionais e modelos distintos

Aplicar [regras dos documentos de 2022 e 2023](regras-documentos-2022-2023.md). A sequência JBI acima não substitui a estrutura do modelo Lely 2023 quando este for escolhido. Lely inclui resumo com Ética e disseminação e Conclusão prospectiva; não atribuir a ele o limite JBI de 250 palavras. Escolher o modelo com a equipe quando houver ambiguidade, sem repetir escolha já explícita.
\n## Distinção obrigatória no planejamento\n\nNo protocolo: necessidade de conhecimento e contribuição pretendida apoiadas na leitura preliminar; eventuais indícios são provisórios e circunscritos às fontes consultadas. Após a revisão: lacunas sustentadas pelo corpus, caso identificadas. Não bloquear a entrevista porque o pesquisador ainda não conhece uma lacuna. Na conclusão prospectiva, retomar a necessidade, sem anunciar achados. Seguir a regra específica no SKILL.md.\n

## Regra de entrevista atualizada

Não solicitar estudos conhecidos, artigos, revisões antecedentes conhecidas ou lacuna conhecida. Perguntar uma coisa por vez para definir a necessidade de conhecimento: o que compreender, por que investigar, para quem importa e quais informações organizar. Validar a formulação proposta e alinhar PCC e objetivos. A ausência de referências não impede essa definição; a fundamentação bibliográfica permanece como tarefa distinta quando necessária.

## Justificativa — conferência obrigatória

Aplicar [justificativa sem antecipação](justificativa-sem-antecipacao.md): entrevistar sobre a necessidade, relevância, informações a organizar e adequação da ScR; não pressupor buscas nem cobrar estudos conhecidos. Verificação de sínteses pendente não impede texto provisório. Se busca preliminar for informada, documentar objetivo, fontes, datas, estratégia e material examinado antes de redigir resultados. Separar necessidade, situação das sínteses e lacunas pós-análise. Conferir planos versus execução e expectativas versus achados, com log de alterações.
